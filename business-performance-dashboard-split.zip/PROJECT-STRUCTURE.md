# Project Structure

- `index.html` — page markup and external library references
- `style.css` — all CSS styling
- `app.js` — authentication, CSV parsing, calculations, chart, and performance insights
- `sample-current-period.csv` — valid current-period test data
- `sample-previous-period.csv` — valid previous-period test data
- `test-missing-column.csv` — missing-column error test
- `test-invalid-number.csv` — invalid-number error test
- `test-missing-value.csv` — missing-value error test
- `README.md` — project documentation

Keep all three main files in the same folder. `index.html` loads `style.css` and `app.js`.
